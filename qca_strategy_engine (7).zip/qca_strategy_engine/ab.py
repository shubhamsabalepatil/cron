[9: 49
am, 21 / 12 / 2022] Ambuj
Tiwari:
from inspect import Parameter
from django.shortcuts import render
from django.conf import settings as conf_settings

# Create your views here.
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from django.core import serializers
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from bson import ObjectId
from django.utils import timezone
import pytz
from helpers.sendResponse import sendResponse

from rest_framework.decorators import api_view, permission_classes
import json
import subprocess
import sys
from datetime import datetime
from strategy.models import volumeStrategy, spreadStrategy
from strategy.seria…
[3: 41
pm, 21 / 12 / 2022] Ambuj
Tiwari: lets
wait
for some time
    [4: 07
    pm, 21 / 12 / 2022] Ambuj
    Tiwari:
    from django.conf import settings as conf_settings

# Create your views here.
from django.http.response import JsonResponse
from helpers.sendResponse import sendResponse
from rest_framework.decorators import api_view
import json
import subprocess
import sys
import os, signal
from helpers.stopExecution import sendStopExecutionOverSocket
import jwt


@api_view(['GET'])
def check(request):
    print("Server Health Check")
    return JsonResponse(sendResponse(200, "Server is running", 'check', None, None), status=200)


@api_view(['POST'])
def startVolumeStrategy(request):
    xToken = request.META.get('HTTP_X_TOKEN')
    if xToken is None:
        return JsonResponse(sendResponse(401, "Not Authorized. Lv0 Failed", 'startVolumeStrategy', "", None),
                            status=401)

    salt = conf_settings.SALT

    decoded_X_Token = jwt.decode(xToken, salt)
    method = decoded_X_Token['method']
    print("METHOD IN HEADER ---->", method)
    if method != 'startVolumeStrategy':
        return JsonResponse(sendResponse(401, "Not Authorized", 'startVolumeStrategy', "", None), status=401)

    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print(body)

    # print("HEADER---->",request.META.get('HTTP_X_TOKEN'))

    requiredKeys = ['webAppHost', 'strategyTransactionId', 'exchange', 'symbol', 'baseCurrency', 'timeInterval',
                    'orderQuantity', 'pricePrecision', 'quantityPrecision', 'tickSize', 'tickDifference',
                    'maxVolumeQuantity', 'onPartialFillOption', 'allowedPriceRange', 'cutOffBaseTokenAmount',
                    'cutOffTokenAmount']

    for key in requiredKeys:
        if key in body:
            pass
        else:
            return JsonResponse(sendResponse(400, "MISSING PARAMS", 'startVolumeStrategy', None, None), status=400)

    parameters = body

    print(parameters, type(parameters))
    # print(parameters['symbol'])
    topicName = parameters['exchange'] + "" + parameters['symbol'] + "" + parameters['baseCurrency']
    print("topic name -->", topicName)
    symbolForScript = parameters['symbol'] + "_" + parameters['baseCurrency']
    print("symbolForScript --->", symbolForScript)

    try:
        consolidateUserSubprocess = subprocess.Popen(
            [sys.executable, 'scripts/volumeStrategy.py', '--webAppHost', str(parameters['webAppHost']),
             '--strategyTransactionId', str(parameters['strategyTransactionId']), '--exchange',
             str(parameters['exchange']), '--token', parameters['symbol'], '--baseCurrency',
             str(parameters['baseCurrency']), '--topic', topicName, '--symbol', symbolForScript, '--timeInterval',
             str(parameters['timeInterval']), '--orderQuantity', str(parameters['orderQuantity']), '--pricePrecision',
             str(parameters['pricePrecision']), '--quantityPrecision', str(parameters['quantityPrecision']),
             '--tickSize', str(parameters['tickSize']), '--tickDifference', str(parameters['tickDifference']),
             '--maxVolumeQuantity', str(parameters['maxVolumeQuantity']), '--onPartialFillOption',
             str(parameters['onPartialFillOption']), '--allowedPriceRange', str(parameters['allowedPriceRange']),
             '--cutOffBaseTokenAmount', str(parameters['cutOffBaseTokenAmount']), '--cutOffTokenAmount',
             str(parameters['cutOffTokenAmount'])])

        PID = consolidateUserSubprocess.pid
        print("PID FOR PROCESSS-->", PID)
        res = {"pid": PID}
        return JsonResponse(sendResponse(200, "Script Started Successfuly", 'runVolumeStrategy', res, None), status=200)
    except Exception as e:
        print("Error while starting script ----> ", e)
        return JsonResponse(sendResponse(500, "Error while starting script", 'runVolumeStrategy', None, None),
                            status=500)


@api_view(['POST'])
def stopStrategy(request):
    xToken = request.META.get('HTTP_X_TOKEN')
    if xToken is None:
        return JsonResponse(sendResponse(401, "Not Authorized. Lv0 Failed", 'stopStrategy', "", None), status=401)

    # print("xToken----->",xToken)
    salt = conf_settings.SALT

    decoded_X_Token = jwt.decode(xToken, salt)
    method = decoded_X_Token['method']
    print("METHOD IN HEADER ---->", method)
    if method != 'stopStrategy':
        return JsonResponse(sendResponse(401, "Not Authorized Lv1 Failed", 'stopStrategy', "", None), status=401)

    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print(body)
    requiredKeys = ['pid', 'exchange', 'baseCurrency', 'symbol']

    for key in requiredKeys:
        if key in body:
            pass
        else:
            return JsonResponse(sendResponse(400, "MISSING PARAMS", 'stopVolumeStrategy', None, None), status=400)

    pids = body['pid']
    if "strategyType" in body:
        strategyType = body['strategyType']
    else:
        strategyType = "ALL"
    exchange = body['exchange']
    baseCurrency = body['baseCurrency']
    symbol = body['symbol']

    print(pids)

    try:
        sendStopExecutionOverSocket(exchange, symbol, baseCurrency, strategyType)
    except Exception as e:
        print("Error in sending over socket --> ", e)
    errorWhileKill = False
    pidsKillResponse = []
    for pid in pids:
        try:
            os.kill(int(pid), signal.SIGKILL)
            pidsKillResponse.append({pid: "success"})
        except OSError as ex:
            print("error while stopping script--->", ex)
            if (ex.errno == 3):
                pidsKillResponse.append({pid: "success"})
            else:
                errorWhileKill = True
                pidsKillResponse.append({pid: "error"})

    if errorWhileKill:
        return JsonResponse(sendResponse(500, "Something Went Wrong", 'stopSpreadScript', pidsKillResponse, None),
                            status=500)

    return JsonResponse(sendResponse(200, "Script Stoped Successfuly", 'stopSpreadScript', pidsKillResponse, None),
                        status=200)


@api_view(['POST'])
def startSpreadStrategy(request):
    xToken = request.META.get('HTTP_X_TOKEN')
    if xToken is None:
        return JsonResponse(sendResponse(401, "Not Authorized. Lv0 Failed", 'startSpreadStrategy', "", None),
                            status=401)

    salt = conf_settings.SALT

    decoded_X_Token = jwt.decode(xToken, salt)
    method = decoded_X_Token['method']
    print("METHOD IN HEADER ---->", method)
    if method != 'startSpreadStrategy':
        return JsonResponse(sendResponse(401, "Not Authorized. Lv1 Failed", 'startSpreadStrategy', "", None),
                            status=401)

    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    # print(body)
    parameters = body

    print(parameters, type(parameters))
    requiredKeys = ['webAppHost', 'strategyTransactionId', 'exchange', 'symbol', 'baseCurrency', 'pricePrecision',
                    'quantityPrecision', 'tickSize', 'percentChangeBid', 'orderSizeBid', 'percentChangeAsk',
                    'orderSizeAsk', 'tickGapRange', 'midPriceChangePercentASK', 'midPriceChangePercentBID',
                    'limitForMidPriceChange', 'bidOrAskPositionCheck', 'positionToPlaceFirstOrderBid',
                    'positionToPlaceFirstOrderAsk', 'onFillOption', 'maximumBuyOrSellLimit', 'cutOffBaseTokenAmount',
                    'cutOffTokenAmount']

    for key in requiredKeys:
        if key in body:
            pass
        else:
            return JsonResponse(sendResponse(400, "MISSING PARAMS", 'startSpreadStrategy', None, None), status=400)

    topicName = parameters['exchange'] + "" + parameters['symbol'] + "" + parameters['baseCurrency']
    print("topic name -->", topicName)
    symbolForScript = parameters['symbol'] + "_" + parameters['baseCurrency']
    print("symbolForScript --->", symbolForScript)

    profitTickSize = 0
    stopTriggerTickValue = 0
    stopLimitTickValue = 0
    stopType = None

    if parameters['onFillOption'] == "OPEN":
        profitTickSize = 0
        stopTriggerTickValue = 0
        stopLimitTickValue = 0
        stopType = ""
    elif parameters['onFillOption'] == "OCO":
        profitTickSize = parameters['profitTickSize']
        stopTriggerTickValue = parameters['profitTickSize']
        stopType = parameters['stopType']
        if parameters['stopType'] == 'LIMIT':
            stopLimitTickValue = parameters['stopLimitTickValue']
        else:
            stopLimitTickValue = 0

    try:

        consolidateUserSubprocess = subprocess.Popen(
            [sys.executable, 'scripts/spreadStrategy.py', '--webAppHost', str(parameters['webAppHost']),
             '--strategyTransactionId', str(parameters['strategyTransactionId']), '--exchange',
             str(parameters['exchange']), '--token', parameters['symbol'], '--baseCurrency',
             str(parameters['baseCurrency']), '--topic', topicName, '--symbol', symbolForScript, '--pricePrecision',
             str(parameters['pricePrecision']), '--quantityPrecision', str(parameters['quantityPrecision']),
             '--tickSize', str(parameters['tickSize']), '--percentChangeBid', str(parameters['percentChangeBid']),
             '--orderSizeBid', str(parameters['orderSizeBid']), '--percentChangeAsk',
             str(parameters['percentChangeAsk']), '--orderSizeAsk', str(parameters['orderSizeAsk']), '--tickGapRange',
             str(parameters['tickGapRange']), '--midPriceChangePercentASK', str(parameters['midPriceChangePercentASK']),
             '--midPriceChangePercentBID', str(parameters['midPriceChangePercentBID']), '--limitForMidPriceChange',
             str(parameters['limitForMidPriceChange']), '--bidOrAskPositionCheck',
             str(parameters['bidOrAskPositionCheck']), '--positionToPlaceFirstOrderBid',
             str(parameters['positionToPlaceFirstOrderBid']),
             '--positionToPlaceFirstOrderAsk', str(parameters['positionToPlaceFirstOrderAsk']), '--onFillOption',
             str(parameters['onFillOption']), '--stopType', str(stopType), '--profitTickSize', str(profitTickSize),
             '--stopTriggerTickValue', str(stopTriggerTickValue), '--stopLimitTickValue', str(stopLimitTickValue),
             "--maximumBuyOrSellLimit", str(parameters['maximumBuyOrSellLimit']), '--cutOffBaseTokenAmount',
             str(parameters['cutOffBaseTokenAmount']), '--cutOffTokenAmount', str(parameters['cutOffTokenAmount'])])

        PID = consolidateUserSubprocess.pid
        print("PID FOR PROCESSS-->", PID)

        res = {"pid": PID}

        return JsonResponse(sendResponse(200, "Script Started Successfuly", 'startSpreadStrategy', res, None),
                            status=200)
    except Exception as e:
        print("Error while starting script ----> ", e)
        return JsonResponse(sendResponse(500, "Error while starting script", 'startSpreadStrategy', None, None),
                            status=500)


@api_view(['POST'])
def startBulkOrderStrategy(request):
    xToken = request.META.get('HTTP_X_TOKEN')
    if xToken is None:
        return JsonResponse(sendResponse(401, "Not Authorized. Lv0 Failed", 'startBulkOrderStrategy', "", None),
                            status=401)

    salt = conf_settings.SALT

    decoded_X_Token = jwt.decode(xToken, salt)
    method = decoded_X_Token['method']
    print("METHOD IN HEADER ---->", method)
    if method != 'startBulkOrderStrategy':
        return JsonResponse(sendResponse(401, "Not Authorized", 'startBulkOrderStrategy', "", None), status=401)

    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print(body)

    # print("HEADER---->",request.META.get('HTTP_X_TOKEN'))

    requiredKeys = ['webAppHost', 'strategyTransactionId', 'exchange', 'symbol', 'baseCurrency', 'pricePrecision',
                    'quantityPrecision', 'tickSize', 'bidOrdersEnabled', 'askOrdersEnabled', 'bidOrdersList',
                    'askOrdersList', 'cutOffBaseTokenAmount', 'cutOffTokenAmount']

    for key in requiredKeys:
        if key in body:
            pass
        else:
            return JsonResponse(sendResponse(400, "MISSING PARAMS", 'startBulkOrderStrategy', None, None), status=400)

    parameters = body

    print(parameters, type(parameters))
    # print(parameters['symbol'])
    topicName = parameters['exchange'] + "" + parameters['symbol'] + "" + parameters['baseCurrency']
    print("topic name -->", topicName)
    symbolForScript = parameters['symbol'] + "_" + parameters['baseCurrency']
    print("symbolForScript --->", symbolForScript)

    try:
        consolidateUserSubprocess = subprocess.Popen(
            [sys.executable,
             'scripts/bulkOrder.py', '--webAppHost', str(parameters['webAppHost']),
             '--strategyTransactionId', str(parameters['strategyTransactionId']),
             '--exchange', str(parameters['exchange']),
             '--token', parameters['symbol'],
             '--baseCurrency', str(parameters['baseCurrency']),
             '--topic', topicName, '--symbol', symbolForScript,
             '--pricePrecision', str(parameters['pricePrecision']),
             '--quantityPrecision', str(parameters['quantityPrecision']),
             '--tickSize', str(parameters['tickSize']),
             '--cutOffBaseTokenAmount', str(parameters['cutOffBaseTokenAmount']),
             '--cutOffTokenAmount', str(parameters['cutOffTokenAmount']),
             '--bidOrdersEnabled', str(parameters['bidOrdersEnabled']),
             '--askOrdersEnabled', str(parameters['askOrdersEnabled']),
             '--bidOrdersList', str(parameters['bidOrdersList']),
             '--askOrdersList', str(parameters['askOrdersList']),
             '--bidOrdersLimitPercent', str(parameters['bidOrdersLimitPercent']),
             '--askOrdersLimitPercent', str(parameters['askOrdersLimitPercent']),
             '--maximumBuyLimit', str(parameters['maximumBuyLimit']),
             '--maximumSellLimit', str(parameters['maximumSellLimit']),
             '--priceCheckType', str(parameters['priceCheckType']),
             '--bidOrdersLimitTicks', str(parameters['bidOrdersLimitTicks']),
             '--askOrdersLimitTicks', str(parameters['askOrdersLimitTicks'])

             ])

        PID = consolidateUserSubprocess.pid
        print("PID FOR PROCESSS-->", PID)
        res = {"pid": PID}
        return JsonResponse(sendResponse(200, "Script Started Successfuly", 'startBulkOrderStrategy', res, None),
                            status=200)
    except Exception as e:
        print("Error while starting script ----> ", e)
        return JsonResponse(sendResponse(500, "Error while starting script", 'startBulkOrderStrategy', None, None),
                            status=500)