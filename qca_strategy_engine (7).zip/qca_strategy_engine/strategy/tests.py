def update():
    print('running')