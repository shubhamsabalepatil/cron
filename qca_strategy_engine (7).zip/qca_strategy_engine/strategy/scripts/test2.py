import os
import time

while(True):
    os.getpid()
    print(os.getpid())
    time.sleep(5)