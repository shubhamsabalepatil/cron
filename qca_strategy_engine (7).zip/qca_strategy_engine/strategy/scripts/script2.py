print('second script')
