import os
import time

while(True):
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    print('script running')
    time.sleep(2)
    break

